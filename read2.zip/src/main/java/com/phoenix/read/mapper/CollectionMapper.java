package com.phoenix.read.mapper;

import com.phoenix.read.MyMapper;
import com.phoenix.read.entity.Collection;
import com.phoenix.read.entity.Like;
import org.springframework.stereotype.Repository;

@Repository
public interface CollectionMapper extends MyMapper<Collection> {
}
